package com.ims.controller;

import com.ims.dto.ReservationRequest;
import com.ims.dto.SupplyRequest;
import com.ims.entity.ItemEntity;
import com.ims.service.impl.InventoryService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

    @Autowired
    private InventoryService service;

    @PostMapping("/supply")
    public ResponseEntity<String> addSupply(@RequestBody SupplyRequest request) {
        service.addSupply(request.getItemId(), request.getQuantity());
        return ResponseEntity.ok("Supply Added");
    }

    @PostMapping("/reserve")
    public ResponseEntity<String> reserve(@RequestBody ReservationRequest request) {
        service.reserveItem(request.getItemId(), request.getQuantity());
        return ResponseEntity.ok("Reserved");
    }

    @PostMapping("/cancel")
    public ResponseEntity<String> cancel(@RequestBody ReservationRequest request) {
        service.cancelReservation(request.getItemId(), request.getQuantity());
        return ResponseEntity.ok("Cancelled");
    }
    @Operation(summary = "Get item by ID")
    @GetMapping("/{itemId}")
    public ResponseEntity<ItemEntity> getItem(@PathVariable String itemId) {
        return ResponseEntity.ok(service.getItemStatus(itemId));
    }
}
