package com.ims.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@Entity
@Data
public class ItemEntity {

    @Id
    private String itemId;

    private int availableQuantity;

    private int reservedQuantity;

    public ItemEntity() {
    }

    public ItemEntity(String item1, int i, int i1) {
    }
}
