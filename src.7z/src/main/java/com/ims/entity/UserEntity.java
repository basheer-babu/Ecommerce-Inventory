package com.ims.entity;

public class UserEntity {
}
