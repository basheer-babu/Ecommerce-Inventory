package com.ims.repo;

import com.ims.entity.ItemEntity;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface InventoryRepository extends JpaRepository<ItemEntity, String> {

        Optional<ItemEntity> findByItemId(String itemId);

        @Lock(LockModeType.PESSIMISTIC_WRITE)
        @Query("SELECT i FROM ItemEntity i WHERE i.itemId = :itemId")
        Optional<ItemEntity> lockItemForUpdate(@Param("itemId") String itemId);
}


