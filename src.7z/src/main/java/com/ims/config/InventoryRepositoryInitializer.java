package com.ims.config;

import com.ims.entity.ItemEntity;
import com.ims.repo.InventoryRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Component
public class InventoryRepositoryInitializer {

    private final InventoryRepository inventoryRepository;

    public InventoryRepositoryInitializer(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    @PostConstruct
    public void init() {
        if (inventoryRepository.count() > 0) return;

        List<ItemEntity> items = IntStream.rangeClosed(1, 50)
            .mapToObj(i -> {
                String itemId = "ITEM" + String.format("%03d", i);
                int available = ThreadLocalRandom.current().nextInt(20, 100);
                int reserved = ThreadLocalRandom.current().nextInt(0, available / 2);

                ItemEntity item = new ItemEntity();
                item.setItemId(itemId);
                item.setAvailableQuantity(available - reserved);
                item.setReservedQuantity(reserved);
                return item;
            })
            .collect(Collectors.toList());

//        ItemEntity item1 = new ItemEntity("item1",110,200);
//        ItemEntity item2 = new ItemEntity("item2",110,200);
//        ItemEntity item3 = new ItemEntity("item3",110,200);
//        ItemEntity item4 = new ItemEntity("item4",110,200);
//        ItemEntity item5 = new ItemEntity("item5",110,200);
//        List<ItemEntity> list = Arrays.asList(item1,item2,item3,item4,item5);

        inventoryRepository.saveAll(items);
        System.out.println("✅ 50 test items inserted via repository initializer.");
    }
}
