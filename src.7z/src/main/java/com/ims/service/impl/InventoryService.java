package com.ims.service.impl;

import com.ims.entity.ItemEntity;
import com.ims.repo.InventoryRepository;
import jakarta.transaction.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepository repo;


    private static final Logger logger = LogManager.getLogger(InventoryService.class);

    public void addSupply(String itemId, int quantity) {
        ItemEntity item = repo.findById(itemId)
            .orElse(new ItemEntity());
        item.setAvailableQuantity(item.getAvailableQuantity() + quantity);
        repo.save(item);
    }
    @Transactional
    public void reserveItem(String itemId, int quantity) {
        logger.info("Reserving item...");
        ItemEntity item = repo.lockItemForUpdate(itemId)
            .orElseThrow(() -> new RuntimeException("Item not found"));

        if (item.getAvailableQuantity() < quantity) {
            throw new RuntimeException("Not enough stock");
        }
        System.out.println("quantity " + quantity);
        System.out.println("av " + item.getAvailableQuantity());
        System.out.println("rv " + item.getReservedQuantity() );

        item.setAvailableQuantity(item.getAvailableQuantity() - quantity);
        item.setReservedQuantity(item.getReservedQuantity() + quantity);
        System.out.println("avaf " + item.getAvailableQuantity());
        System.out.println("rvaf " + item.getReservedQuantity() );
        repo.save(item);
    }
    @Transactional
    public void cancelReservation(String itemId, int quantity) {
        ItemEntity item = repo.lockItemForUpdate(itemId)
            .orElseThrow(() -> new RuntimeException("Item not found"));

        if (item.getReservedQuantity() < quantity) {
            throw new RuntimeException("Not enough reserved items");
        }

        item.setReservedQuantity(item.getReservedQuantity() - quantity);
        item.setAvailableQuantity(item.getAvailableQuantity() + quantity);
        repo.save(item);
    }

    @Cacheable(value = "inventory", key = "#itemId")
    public ItemEntity getItemStatus(String itemId) {
        return repo.findById(itemId)
            .orElseThrow(() -> new RuntimeException("Item not found"));
    }
}
