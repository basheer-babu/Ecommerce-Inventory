package com.ims.dto;

import lombok.Data;

@Data
public class SupplyRequest {
    private String itemId;
    private int quantity;
}