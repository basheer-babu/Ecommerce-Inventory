package com.ims.dto;

import lombok.Data;

@Data
public class ReservationRequest {
    private String itemId;
    private int quantity;
}